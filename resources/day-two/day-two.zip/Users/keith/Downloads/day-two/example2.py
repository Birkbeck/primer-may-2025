# print("Hello", "You")
# print("Hello " + "You")

# "+" is overloaded.
# The action of "+" is dependent upon context
# Usually the context is the type of the operands

# Get string length
str3 = "Hello You"
# print("Length ", len(str3))

# Character at index
# print("1st ", str3[0])

# Last character
# print("Last ", str3[-1])
# print("Last ", str3[len(str3)-1])

# string slicing
# 1st 3 chrs
# print("1st 3 ", str3[0:3])  # Start, up to not including

# Test if string in string
#print("you" in str3)
# Test if not in
#print("you" not in str3)

# Find first index for match or -1
#print("You Index ", str3.find("You"))

# Trim white space from right and left
# also lstrip and rstrip
#print("    Hello    ".strip())

# To lower and upper case
print("A String".lower())
print("A String".upper())
