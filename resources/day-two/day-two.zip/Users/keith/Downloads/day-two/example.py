# Examples from Day Two of the Primer

# print("Hello World!")

# name = input("What is your name: ")
# print("Hi", name)

# Split expression over multiple lines
# v1 = ( 1 + 2 
#     + 3 )
# print("The value is: ", v1)

"""
This is a multi-line comment
"""

# v1 = 5
# v2 = v1

# assignment of multiple variables
# v1 = v2 = 5

# print(v1,v2)

# Don't do the above

# types
# print(type(10))
# print(type(10.5))
# maximum size of a particular type
import sys
# print(sys.maxsize)
# print(sys.float_info.max)

# precision (accuracy)

# f1 = 1.1111111111111111111111
# f2 = 1.1111111111111111111111
# f3 = f1 + f2
# print(f3)

# Complex mumber
# cn1 = 5 + 6j

# print(cn1)

# illegal
#x = 3 + "asd"

# a = "aasds"
# print(a)
# a = 34
# print(a)

# Type conversions (casts)
# print("Cast ", type(int(5.4)))  # to int
# print("Cast 2 ", type(str(5.4)))  # to string
# print("Cast 3 ", type(chr(97)))  # to string
# print("Cast 4 ", type(ord('a')))  # to int

# print("Cast ", int(5.4))  # to int
# print("Cast 2 ", str(5.4))  # to string
# print("Cast 3 ", chr(97))  # to string
# print("Cast 4 ", ord('a'))  # to int

# You can define a separator for print
#print(12, 21, 1974, sep='/')
#print("5.4" + 3)
#print(float("5.4") + 3)

# ----- MATH -----
# print("5 + 2 =", 5 + 2)
# print("5 - 2 =", 5 - 2)
# print("5 * 2 =", 5 * 2)
# print("5 / 2 =", 5 / 2) 
# print("5 % 2 =", 5 % 2) # remainder of integer division
# print("5 ** 2 =", 5 ** 2)
# print("5 // 2 =", 5 // 2) # integer division modulus

# import math
# print("abs(-1) ", abs(-1))
# print("max(5, 4) ", max(5, 4))
# print("min(5, 4) ", min(5, 4))
# print("pow(2, 2) ", pow(2, 2))
# print("ceil(4.5) ", math.ceil(4.5))
# print("floor(4.5) ", math.floor(4.5))
# print("round(4.5) ", round(4.5))
# print("exp(1) ", math.exp(1))  # e**x
# print("log(e) ", math.log(math.exp(1)))
# print("log(100) ", math.log(100, 10))  # Base 10 Log
# print("sqrt(100) ", math.sqrt(100))
# print("sin(0) ", math.sin(0))
# print("cos(0) ", math.cos(0))
# print("tan(0) ", math.tan(0))
# print("asin(0) ", math.asin(0))
# print("acos(0) ", math.acos(0))
# print("atan(0) ", math.atan(0))
# print("sinh(0) ", math.sinh(0))
# print("cosh(0) ", math.cosh(0))
# print("tanh(0) ", math.tanh(0))
# print("asinh(0) ", math.asinh(0))
# print("acosh(pi) ", math.acosh(math.pi))
# print("atanh(0) ", math.atanh(0))
# print("hypot(0) ", math.hypot(10, 10))  # sqrt(x*x + y*y)
# print("radians(0) ", math.radians(0))
# print("degrees(pi) ", math.degrees(math.pi))

import random
# Generate a random int
#print("Random", random.randint(1, 101))

# revision of conditionals
# introduce the idea of "Magic Numbers"
# age = 30

# BABY = 4
# INFANT = 5
# ADULT = 18

# if age < BABY:
#     print("Stay home!")
# elif (age >= BABY) and (age <= INFANT):
#     print("Nursery")
# elif (age > INFANT) and (age <= ADULT):
#     print("School")
# else:
#     print("World")

# Strings and string slicing

str1 = "Hello World"
# print(str1)
# print("Length: ",len(str1))

# strings are numbered by index from 0
print(str1[0])
print(str1[len(str1)-1])