# pre-Test
# mid-Test
# post-Test

# While : Execute while condition is True

# w1 = 1
# LIMIT = 5

# while w1 < LIMIT:
#   print(w1)
#   w1 = w1 + 1 # w1 += 1

# w2 = 0
# LIMIT = 20
# while w2 <= LIMIT:
#   if w2 % 2 == 0:
#     print(w2)
#   elif w2 == 9: # stop the loop completely
#     break
#   else:
#     w2 = w2 + 1 # w2 += 1
#     continue
#   w2 = w2 + 1

 # https://pythontutor.com/

# For Loop
# Allows you to perform an action a set number of times
# Range performs the action 10 times 0 - 9

# for x in range(0,10):
#   print(x)

# print()

# x = 0
# LIMIT = 10
# while x < LIMIT:
#   print(x)
#   x += 1

# "syntactical sugar"

# mid Test

while True:
  name = input("What is your name ('end' to finish)")
  if name == "end":
    break
  print("The name you provided is:", name)

# pre test 0 or more times
# post test 1 or more times