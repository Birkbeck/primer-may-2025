l1 = [1,3.14, "Fred", True]
#print(type(l1))
print(l1)

# Get length
#print("Length ", len(l1))

# Get value at index
# print("1st", l1[0])
# print("Last", l1[-1])

# Change value
l1[0] = 2
print(l1)
print(type(l1[2]))

l1.remove("Fred")
print(l1)
# mutable = change the values within a list

l1.pop(1)
print(l1)
l1.insert(len(l1),"X")
l1.insert(len(l1),"Y")

print(l1)

# slicing
print("1st 2", l1[0:2])
print("Every Other ", l1[0:-1:2])
print("Reverse ", l1[::-1])